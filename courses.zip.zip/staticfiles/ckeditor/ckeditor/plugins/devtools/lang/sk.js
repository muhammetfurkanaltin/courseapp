﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","sk",{title:"Informácie o prvku",dialogName:"Názov okna dialógu",tabName:"Názov záložky",elementId:"ID prvku",elementType:"Typ prvku"});